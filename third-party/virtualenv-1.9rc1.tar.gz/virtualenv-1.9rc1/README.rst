virtualenv
==========

.. image:: https://secure.travis-ci.org/pypa/virtualenv.png?branch=develop
   :target: http://travis-ci.org/pypa/virtualenv

For documentation, see http://www.virtualenv.org/
